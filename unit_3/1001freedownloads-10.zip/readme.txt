Thank you for downloading this file from www.1001FreeDownloads.com

License and terms of use:

• You must place a link on your website to http://www.1001FreeDownloads.com (you may also link to the actual download page). If using it offline, please print the URL of our website as a form of attribution.

• This file can be used for personal and commercial purposes.

• Redistribution of this file via any online or offline methods is strictly forbidden without explicit written authorization from us.

• You may use/modify this file as part of templates, ebooks, offline presentations and others with proper attribution, provided that the source files are not included.

• This file cannot be sub-licensed, sold or rented.

If you have any questions about these terms, please contact us at info@1001freedownloads.com 